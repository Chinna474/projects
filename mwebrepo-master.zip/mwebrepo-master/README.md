# maven-project

This is a tokenized webhook integration demo

Now This repo is going to trigger Jenkins Job

Simple Maven Project

This is a Master branch copy
